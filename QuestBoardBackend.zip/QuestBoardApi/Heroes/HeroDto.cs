﻿using System.ComponentModel.DataAnnotations;
using QuestBoard.Models;
using System.Text.Json.Serialization;
namespace QuestBoard.Heroes;

// DTO do zwracania szczegółów bohatera
public record HeroResponse(
    int Id,
    string Name,
    string Icon,
    [property: JsonPropertyName("cls")] string Class,
    [property: JsonPropertyName("lvl")] int Level,
    [property: JsonPropertyName("gold")] int GoldCoins,
    int Completed,
    List<InventoryItemResponse> Inventory
);

// Rekordy pomocnicze
public record InventoryItemResponse(
    string Icon,
    string Name
);

// DTO do zwracania listy questów

public record QuestSummaryResponse(
    int Id,
    string Title,
    string Status,
    string RegionName
);


// DTO do przyjmowania danych od klienta (z automatyczną walidacją)
public record JoinQuestRequest(
    [Required(ErrorMessage = "Id bohatera jest wymagane.")]
    [Range(1, int.MaxValue, ErrorMessage = "Id bohatera musi być większe od zera.")]
    int HeroId
);