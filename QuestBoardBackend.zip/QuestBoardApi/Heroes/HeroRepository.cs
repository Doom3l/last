using Microsoft.EntityFrameworkCore;
using QuestBoard.Data;
using QuestBoard.Models;

namespace QuestBoard.Heroes;

public class HeroRepository : IHeroRepository
{
    private readonly AppDbContext _db;

    public HeroRepository(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<Hero>> GetAllAsync(HeroClass? heroClass, int? minLevel)
    {
        var query = _db.Heroes.AsNoTracking();
        if (heroClass.HasValue) query = query.Where(h => h.Class == heroClass.Value);
        if (minLevel.HasValue)  query = query.Where(h => h.Level >= minLevel.Value);
        return await query.OrderBy(h => h.Name).ToListAsync();
    }

    public async Task<Hero?> GetByIdAsync(int id) => await _db.Heroes.FindAsync(id);

    public async Task<List<Hero>> GetRankingAsync()
    {
        // dostosowanie do frontu: Include QuestHeroes żeby liczyć completed w kontrolerze
        // poprzednio: _db.Heroes.AsNoTracking().OrderByDescending(h => h.GoldCoins).ToListAsync()
        return await _db.Heroes
            .Include(h => h.QuestHeroes).ThenInclude(qh => qh.Quest)
            .AsNoTracking()
            .OrderByDescending(h => h.GoldCoins)
            .ToListAsync();
    }

    public async Task<List<QuestHero>> GetQuestsAsync(int heroId)
    {
        var hero = await _db.Heroes
            .Include(h => h.QuestHeroes)
                .ThenInclude(qh => qh.Quest)
                    .ThenInclude(q => q.Region)
            .AsNoTracking()
            .FirstOrDefaultAsync(h => h.Id == heroId);

        return hero?.QuestHeroes ?? new List<QuestHero>();
    }

    public async Task<bool> JoinQuestAsync(int questId, int heroId)
    {
        var quest = await _db.Quests
            .Include(q => q.QuestHeroes)
            .FirstOrDefaultAsync(q => q.Id == questId);

        if (quest is null) return false;
        if (quest.Status != QuestStatus.Open) return false;
        if (quest.QuestHeroes.Any(qh => qh.HeroId == heroId)) return false;
        if (quest.QuestHeroes.Count >= 3) return false;

        var isFirstHero = quest.QuestHeroes.Count == 0;
        _db.QuestHeroes.Add(new QuestHero
        {
            QuestId  = questId,
            HeroId   = heroId,
            IsLeader = isFirstHero,
            JoinedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> LeaveQuestAsync(int questId, int heroId)
    {
        var quest = await _db.Quests
            .Include(q => q.QuestHeroes)
            .FirstOrDefaultAsync(q => q.Id == questId);

        if (quest is null) return false;
        var heroToRemove = quest.QuestHeroes.FirstOrDefault(qh => qh.HeroId == heroId);
        if (heroToRemove is null) return false;

        _db.QuestHeroes.Remove(heroToRemove);

        if (heroToRemove.IsLeader && quest.QuestHeroes.Count > 1)
        {
            var newLeader = quest.QuestHeroes
                .Where(qh => qh.HeroId != heroId)
                .OrderBy(qh => qh.JoinedAt)
                .First();
            newLeader.IsLeader = true;
        }

        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<Hero> CreateAsync(Hero hero)
    {
        _db.Heroes.Add(hero);
        await _db.SaveChangesAsync();
        return hero;
    }

    public async Task<bool> UpdateAsync(int id, Hero updatedHero)
    {
        var hero = await _db.Heroes.FindAsync(id);
        if (hero is null) return false;
        hero.Name      = updatedHero.Name;
        hero.Level     = updatedHero.Level;
        hero.GoldCoins = updatedHero.GoldCoins;
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var hero = await _db.Heroes.FindAsync(id);
        if (hero is null) return false;
        _db.Heroes.Remove(hero);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> StartQuestAsync(int questId, int heroId)
    {
        var quest = await _db.Quests
            .Include(q => q.QuestHeroes)
            .FirstOrDefaultAsync(q => q.Id == questId);

        if (quest is null) return false;
        var member = quest.QuestHeroes.FirstOrDefault(qh => qh.HeroId == heroId);
        if (member is null || !member.IsLeader || quest.Status != QuestStatus.Open) return false;

        quest.Status = QuestStatus.InProgress;
        await _db.SaveChangesAsync();
        return true;
    }
}
