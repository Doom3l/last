﻿using QuestBoard.Models;

namespace QuestBoard.Heroes;

public interface IHeroRepository
{
    Task<List<Hero>> GetAllAsync(HeroClass? heroClass, int? minLevel);
    Task<Hero?> GetByIdAsync(int id);
    Task<List<Hero>> GetRankingAsync();
    Task<List<QuestHero>> GetQuestsAsync(int heroId);
    Task<bool> JoinQuestAsync(int questId, int heroId);
    Task<bool> LeaveQuestAsync(int questId, int heroId);
    Task<Hero> CreateAsync(Hero hero);
    Task<bool> UpdateAsync(int id, Hero updatedHero);
    Task<bool> DeleteAsync(int id);
    Task<bool> StartQuestAsync(int questId, int heroId);
}