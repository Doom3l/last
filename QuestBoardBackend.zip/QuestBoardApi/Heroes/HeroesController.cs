using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuestBoard.Data;
using QuestBoard.Models;

namespace QuestBoard.Heroes;

[ApiController]
[Route("api/heroes")]
[Tags("🧙 Bohaterowie")]
public class HeroesController : ControllerBase
{
    private readonly IHeroRepository _repo;
    private readonly AppDbContext _db;

    // dostosowanie do frontu: dodano AppDbContext do pobierania ekwipunku i questów
    public HeroesController(IHeroRepository repo, AppDbContext db)
    {
        _repo = repo;
        _db   = db;
    }

    [HttpGet("ranking")]
    [AllowAnonymous]
    public async Task<ActionResult> GetRanking()
    {
        var ranking = await _repo.GetRankingAsync();

        // dostosowanie do frontu: ranking wymaga icon, completed, gold (nie GoldCoins)
        // poprzednio: var dtos = ranking.Select(h => new { h.Name, gold = h.GoldCoins }).ToList();
        var dtos = ranking.Select(h => new
        {
            h.Id,
            h.Name,
            h.Icon,
            gold      = h.GoldCoins,
            lvl       = h.Level,
            cls       = h.Class.ToString(),
            completed = h.QuestHeroes.Count(qh => qh.Quest.Status == QuestStatus.Completed),
        }).ToList();

        return Ok(dtos);
    }

    [HttpGet("me")]
    [Authorize]
    public async Task<ActionResult<HeroResponse>> GetMe()
    {
        var heroIdClaim = User.FindFirst("heroId")?.Value;
        if (string.IsNullOrEmpty(heroIdClaim)) return Forbid();

        var heroId = int.Parse(heroIdClaim);

        // dostosowanie do frontu: ładujemy HeroItems i QuestHeroes żeby wypełnić inventory i completed
        var hero = await _db.Heroes
            .Include(h => h.HeroItems).ThenInclude(hi => hi.Item)
            .Include(h => h.QuestHeroes).ThenInclude(qh => qh.Quest)
            .FirstOrDefaultAsync(h => h.Id == heroId);

        if (hero is null) return NotFound();

        return Ok(MapToResponse(hero));
    }

    [HttpGet("me/quests")]
    [Authorize]
    public async Task<ActionResult<List<QuestSummaryResponse>>> GetMyQuests()
    {
        var heroId = int.Parse(User.FindFirst("heroId")!.Value);
        var quests = await _repo.GetQuestsAsync(heroId);

        var dtos = quests.Select(qh => new QuestSummaryResponse(
            qh.Quest.Id, qh.Quest.Title, qh.Quest.Status.ToString(), qh.Quest.Region.Name
        )).ToList();

        return Ok(dtos);
    }

    [HttpGet]
    [Authorize]
    public async Task<ActionResult<List<HeroResponse>>> GetAll(
        [FromQuery] HeroClass? @class, [FromQuery] int? minLevel)
    {
        var heroes = await _repo.GetAllAsync(@class, minLevel);
        var dtos = heroes.Select(h => new HeroResponse(
            h.Id, h.Name, h.Icon ?? "", h.Class.ToString(), h.Level, h.GoldCoins,
            0, new List<InventoryItemResponse>())).ToList();
        return Ok(dtos);
    }

    [HttpGet("{id}")]
    [Authorize]
    public async Task<ActionResult<HeroResponse>> GetById(int id)
    {
        var hero = await _repo.GetByIdAsync(id);
        if (hero is null) return NotFound();

        return Ok(new HeroResponse(
            hero.Id, hero.Name, hero.Icon ?? "", hero.Class.ToString(), hero.Level, hero.GoldCoins,
            0, new List<InventoryItemResponse>()
        ));
    }

    // dostosowanie do frontu: join/leave/start przeniesione do QuestsController
    // żeby nie było duplikatu routingu — pozostawiamy tu zakomentowane
    // [HttpPost("/api/quests/{id}/join")]
    // [HttpDelete("/api/quests/{id}/leave")]
    // [HttpPost("/api/quests/{id}/start")]

    private static HeroResponse MapToResponse(Hero hero)
    {
        // dostosowanie do frontu: inventory jako lista {icon, name}, completed z questów
        var inventory = hero.HeroItems
            .Select(hi => new InventoryItemResponse(hi.Item.Icon, hi.Item.Name))
            .ToList();

        var completed = hero.QuestHeroes
            .Count(qh => qh.Quest?.Status == QuestStatus.Completed);

        return new HeroResponse(
            hero.Id, hero.Name, hero.Icon ?? "",
            hero.Class.ToString(), hero.Level, hero.GoldCoins,
            completed, inventory
        );
    }
}
