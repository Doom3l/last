﻿using QuestBoard.Models;

namespace QuestBoard.Quests;

public interface IQuestRepository
{
    Task<List<Quest>> GetAllAsync(QuestStatus? status);

    Task<Quest?> GetByIdAsync(int id);

    Task<Quest> CreateAsync(Quest quest);

    Task<bool> UpdateStatusAsync(int id, QuestStatus status);

    Task<bool> SubmitReportAsync(int id, string report);

    Task<bool> ReviewAsync(int id, bool approved, string? reason);
}