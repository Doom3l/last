﻿using Microsoft.EntityFrameworkCore;
using QuestBoard.Data;
using QuestBoard.Models;

namespace QuestBoard.Quests;

public class QuestRepository : IQuestRepository
{
    // dostęp do bazy
    private readonly AppDbContext _db;

    public QuestRepository(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<Quest>> GetAllAsync(QuestStatus? status)
    {
        var query = _db.Quests
            .AsNoTracking()
            .Include(q => q.Region)
            .Include(q => q.QuestHeroes)  // dostosowanie do frontu: potrzebne dla party
                .ThenInclude(qh => qh.Hero)
            .AsQueryable();

        // filtr po statusie
        if (status.HasValue)
            query = query.Where(q => q.Status == status.Value);

        // sortowanie po tytule
        return await query.OrderBy(q => q.Title).ToListAsync();
    }

    // pobierz quest po id
    public async Task<Quest?> GetByIdAsync(int id)
    {
        return await _db.Quests
            .Include(q => q.Region)
            .Include(q => q.QuestHeroes)
                .ThenInclude(qh => qh.Hero)
            .AsNoTracking()
            .FirstOrDefaultAsync(q => q.Id == id);
    }

    // utwórz nowy quest
    public async Task<Quest> CreateAsync(Quest quest)
    {
        // dodanie do bazy
        _db.Quests.Add(quest);

        // zapis zmian
        await _db.SaveChangesAsync();

        return quest;
    }

    // zmiana statusu questa
    public async Task<bool> UpdateStatusAsync(int id, QuestStatus status)
    {
        var quest = await _db.Quests.FindAsync(id);

        // brak questa
        if (quest is null)
            return false;

        // ustaw nowy status
        quest.Status = status;

        await _db.SaveChangesAsync();

        return true;
    }

    // wysłanie raportu
    public async Task<bool> SubmitReportAsync(int id, string report)
    {
        // tylko InProgress
        var quest = await _db.Quests
            .FirstOrDefaultAsync(q => q.Id == id && q.Status == QuestStatus.InProgress);

        // brak lub zły status
        if (quest is null)
            return false;

        // zapis raportu
        quest.CompletionReport = report;

        // zmiana na review
        quest.Status = QuestStatus.InReview;

        await _db.SaveChangesAsync();

        return true;
    }

    // review raportu
    public async Task<bool> ReviewAsync(int id, bool approved, string? reason)
    {
        // znajdź questa
        var quest = await _db.Quests.FindAsync(id);

        // musi być InReview
        if (quest is null || quest.Status != QuestStatus.InReview)
            return false;

        if (approved)
        {
            quest.Status = QuestStatus.Completed;

            quest.RejectionReason = null;
        }
        else
        {
            quest.RejectionReason = reason;

            // wróć do progress
            quest.Status = QuestStatus.InProgress;
        }

        await _db.SaveChangesAsync();

        return true;
    }
}