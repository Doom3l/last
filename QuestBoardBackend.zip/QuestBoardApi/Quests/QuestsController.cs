using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using QuestBoard.Heroes;
using QuestBoard.Models;
using System.Text.Json.Serialization;

namespace QuestBoard.Quests;

[ApiController]
[Route("api/quests")]
[Tags("⚔️ Questy")]
[Authorize]
public class QuestsController : ControllerBase
{
    private readonly IQuestRepository _repo;
    private readonly QuestService _service;
    private readonly IHeroRepository _heroes;

    public QuestsController(IQuestRepository repo, QuestService service, IHeroRepository heroes)
    {
        _repo = repo;
        _service = service;
        _heroes = heroes;
    }

    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<QuestResponse>), StatusCodes.Status200OK)]
    // dostosowanie do frontu: dodano filtry difficulty i regionId
    public async Task<ActionResult<List<QuestResponse>>> GetAll(
        [FromQuery] QuestStatus? status,
        [FromQuery] string? difficulty,
        [FromQuery] int? regionId)
    {
        var quests = await _repo.GetAllAsync(status);

        // dostosowanie do frontu: filtrowanie po difficulty (string z frontu)
        if (!string.IsNullOrEmpty(difficulty))
            quests = quests.Where(q => q.Difficulty.ToString() == difficulty).ToList();

        // dostosowanie do frontu: filtrowanie po regionId
        if (regionId.HasValue)
            quests = quests.Where(q => q.RegionId == regionId.Value).ToList();

        var result = quests.Select(MapToResponse).ToList();
        return Ok(result);
    }

    [HttpGet("review")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(List<QuestResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<QuestResponse>>> GetReviewQueue()
    {
        var quests = await _repo.GetAllAsync(QuestStatus.InReview);
        return Ok(quests.Select(MapToResponse).ToList());
    }

    [HttpGet("{id:int}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(QuestResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<QuestResponse>> GetById(int id)
    {
        var quest = await _service.GetByIdAsync(id);
        return quest is null ? NotFound() : Ok(quest);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(QuestResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<QuestResponse>> Create(CreateQuestRequest request)
    {
        var quest = new Quest
        {
            Title = request.Title,
            Description = request.Description,
            Difficulty = request.Difficulty,
            MinLevel = request.MinLevel,
            RewardGold = request.RewardGold,
            Status = QuestStatus.Open,
            RegionId = request.RegionId,
            RequiredClass = request.RequiredClass
        };

        var created = await _repo.CreateAsync(quest);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, MapToResponse(created));
    }

    [HttpPost("{id:int}/join")]
    [Authorize(Roles = "Hero")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Join(int id)
    {
        var heroId = int.Parse(User.FindFirst("heroId")!.Value);
        var ok = await _heroes.JoinQuestAsync(id, heroId);
        return ok ? NoContent() : BadRequest("Nie można dołączyć do questa.");
    }

    [HttpPost("{id:int}/start")]
    [Authorize(Roles = "Hero")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Start(int id)
    {
        var heroId = int.Parse(User.FindFirst("heroId")!.Value);
        var ok = await _heroes.StartQuestAsync(id, heroId);
        return ok ? NoContent() : BadRequest("Nie można rozpocząć questa.");
    }

    [HttpDelete("{id:int}/leave")]
    [Authorize(Roles = "Hero")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Leave(int id)
    {
        var heroId = int.Parse(User.FindFirst("heroId")!.Value);
        var ok = await _heroes.LeaveQuestAsync(id, heroId);
        return ok ? NoContent() : BadRequest("Nie można opuścić questa.");
    }

    [HttpPut("{id:int}/status")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateStatus(int id, [FromQuery] string value)
    {
        if (!Enum.TryParse<QuestStatus>(value, true, out var parsedStatus))
            return BadRequest($"Invalid status value: {value}");
        var ok = await _repo.UpdateStatusAsync(id, parsedStatus);
        return ok ? NoContent() : NotFound();
    }

    [HttpPost("{id:int}/complete")]
    [Authorize(Roles = "Hero")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> Complete(int id, CompleteQuestRequest request)
    {
        var heroId = int.Parse(User.FindFirst("heroId")!.Value);
        var quest = await _repo.GetByIdAsync(id);
        if (quest is null) return NotFound();
        if (!quest.QuestHeroes.Any(qh => qh.HeroId == heroId)) return Forbid();
        var ok = await _repo.SubmitReportAsync(id, request.Report);
        return ok ? NoContent() : NotFound();
    }

    [HttpPut("{id:int}/review")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Review(int id, ReviewQuestRequest request)
    {
        var ok = await _service.ReviewAsync(id, request.Approved, request.RejectionReason);
        return ok ? NoContent() : NotFound();
    }

    private static QuestResponse MapToResponse(Quest quest)
    {
        return new QuestResponse(
            quest.Id,
            quest.Title,
            quest.Icon,
            quest.Description,
            quest.Difficulty.ToString(),
            quest.MinLevel,
            quest.RewardGold,
            quest.Status.ToString(),
            quest.RegionId,
            quest.RequiredClass?.ToString(),
            quest.CompletionReport,
            quest.RejectionReason,
            quest.QuestHeroes?
                .Select(qh => new PartyMemberResponse(qh.Hero?.Name ?? "", qh.IsLeader))
                .ToList() ?? new List<PartyMemberResponse>(),
            null
        );
    }
}

public record CompleteQuestRequest(string Report);

// dostosowanie do frontu
public record ReviewQuestRequest(
    [property: JsonPropertyName("approve")] bool Approved,
    [property: JsonPropertyName("reason")] string? RejectionReason
);
