﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using QuestBoard.Models;

namespace QuestBoard.Quests;

public record QuestResponse(
    int Id,
    string Title,
    string Icon,

    [property: JsonPropertyName("desc")]
    string Description,

    [property: JsonPropertyName("diff")]
    string Difficulty,

    [property: JsonPropertyName("minLvl")]
    int MinLevel,

    [property: JsonPropertyName("reward")]
    int RewardGold,

    string Status,
    int RegionId,

    [property: JsonPropertyName("reqClass")]
    string? RequiredClass,

    [property: JsonPropertyName("report")]
    string? CompletionReport,

    string? RejectionReason,

    List<PartyMemberResponse> Party,

    ActiveEventResponse? ActiveEvent
);

public record PartyMemberResponse(
    string Name,
    bool Leader
);

public record ActiveEventResponse(
    string Title,

    [property: JsonPropertyName("desc")]
    string Description,

    [property: JsonPropertyName("bonus")]
    int BonusPercent
);

public record CreateQuestRequest(
    [Required(ErrorMessage = "Tytuł jest wymagany")]
    string Title,

    [Required(ErrorMessage = "Opis jest wymagany")]
    string Description,

    [Range(1, 9, ErrorMessage = "Difficulty musi być w zakresie 1-9")]
    Difficulty Difficulty,

    [Range(1, 99, ErrorMessage = "Minimalny poziom musi być dodatni")]
    int MinLevel,

    [Range(50, 1000, ErrorMessage = "Nagroda musi być między 50 a 1000")]
    int RewardGold,

    [Range(1, int.MaxValue, ErrorMessage = "RegionId musi być dodatni")]
    int RegionId,

    HeroClass? RequiredClass
);