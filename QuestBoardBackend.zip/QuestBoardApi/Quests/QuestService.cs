﻿using QuestBoard.Heroes;
using QuestBoard.Models;
using QuestBoard.Regions;

namespace QuestBoard.Quests;

public class QuestService
{
    private readonly IQuestRepository _quests;
    private readonly IRegionRepository _regions;
    private readonly IHeroRepository _heroes;

    public QuestService(IQuestRepository quests, IRegionRepository regions, IHeroRepository heroes)
    {
        _quests = quests;
        _regions = regions;
        _heroes = heroes;
    }

    public async Task<QuestResponse?> GetByIdAsync(int id)
    {
        var quest = await _quests.GetByIdAsync(id);

        if (quest is null)
            return null;

        var activeEvent = await _regions.GetActiveEventForRegionAsync(quest.RegionId);

        return new QuestResponse(
            quest.Id,
            quest.Title,
            quest.Icon,
            quest.Description,
            quest.Difficulty.ToString(),
            quest.MinLevel,
            quest.RewardGold,
            quest.Status.ToString(),
            quest.RegionId,
            quest.RequiredClass?.ToString(),
            quest.CompletionReport,
            quest.RejectionReason,
            quest.QuestHeroes
                .Select(qh => new PartyMemberResponse(
                    qh.Hero!.Name,
                    qh.IsLeader))
                .ToList(),
            activeEvent is null
                ? null
                : new ActiveEventResponse(
                    activeEvent.Title,
                    activeEvent.Description,
                    activeEvent.BonusPercent)
        );
    }

    public async Task<bool> ReviewAsync(int id, bool approved, string? reason)
    {
        var quest = await _quests.GetByIdAsync(id);

        if (quest is null || quest.Status != QuestStatus.InReview)
            return false;

        if (!approved)
            return await _quests.ReviewAsync(id, false, reason);

        var activeEvent = await _regions.GetActiveEventForRegionAsync(quest.RegionId);
        var bonusPercent = activeEvent?.BonusPercent ?? 0;

        var effectiveReward =
            (int)Math.Round(quest.RewardGold * (1 + bonusPercent / 100.0));

        var members = quest.QuestHeroes.ToList();

        if (members.Count == 0)
            return false;

        var share = effectiveReward / members.Count;
        var remainder = effectiveReward % members.Count;

        foreach (var qh in members)
        {
            var hero = await _heroes.GetByIdAsync(qh.HeroId);

            if (hero is not null)
            {
                hero.GoldCoins += share + (qh.IsLeader ? remainder : 0);
                await _heroes.UpdateAsync(hero.Id, hero);
            }
        }

        return await _quests.ReviewAsync(id, true, null);
    }
}