﻿// Regions/RegionValidator.cs
using FluentValidation;

namespace QuestBoard.Regions;

public class CreateEventRequestValidator : AbstractValidator<CreateEventRequest>
{
    public CreateEventRequestValidator()
    {
        RuleFor(r => r.Title)
            .NotEmpty().WithMessage("Tytuł jest wymagany");

        RuleFor(r => r.BonusPercent)
            .InclusiveBetween(0, 100)
            .WithMessage("Bonus musi być między 0 a 100");

        RuleFor(r => r.StartsAt)
            .NotEmpty().WithMessage("Data rozpoczęcia jest wymagana")
            .LessThan(r => r.EndsAt)
            .WithMessage("Data rozpoczęcia musi być wcześniej niż data zakończenia");

        RuleFor(r => r.EndsAt)
            .NotEmpty().WithMessage("Data zakończenia jest wymagana");
    }
}