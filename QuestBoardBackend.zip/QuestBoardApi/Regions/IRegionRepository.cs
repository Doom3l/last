﻿using QuestBoard.Models;

namespace QuestBoard.Regions;

public interface IRegionRepository
{
    Task<List<Region>> GetAllAsync(int? minDanger = null);
    Task<Region?> GetByIdAsync(int id);
    Task<Region> CreateAsync(Region region);
    Task<bool> UpdateAsync(int id, Region updated);
    Task<bool> DeleteAsync(int id);

    Task<List<RegionEvent>> GetEventsFromRegionAsync(int regionId);
    Task<List<RegionEvent>> GetActiveEventsAsync();
    Task<RegionEvent> CreateEventAsync(RegionEvent e);
    Task<bool> UpdateEventAsync(int id, RegionEvent updated);
    Task<bool> DeleteEventAsync(int id);

    Task<List<RegionEvent>> GetAllEventsAsync();
    Task<RegionEvent?> GetActiveEventForRegionAsync(int regionId);

}