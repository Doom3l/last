// Regions/RegionDto.cs
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace QuestBoard.Regions;

// dostosowanie do frontu: dodano Icon (front używa r.icon)
public record RegionResponse(
    int    Id,
    string Name,
    string Icon,
    [property: JsonPropertyName("desc")]   string Description,
    [property: JsonPropertyName("danger")] int    DangerLevel
);

// dostosowanie do frontu: dodano RegionId (front filtruje eventy po e.regionId)
public record EventResponse(
    int      Id,
    string   Title,
    [property: JsonPropertyName("desc")]  string   Description,
    [property: JsonPropertyName("bonus")] int      BonusPercent,
    DateTime StartsAt,
    DateTime EndsAt,
    int      RegionId  // dostosowanie do frontu
);

public record RegionDetailResponse(
    int              Id,
    string           Name,
    string           Description,
    int              DangerLevel,
    List<EventResponse> Events
);

public record CreateRegionRequest(
    [Required(ErrorMessage = "Nazwa jest wymagana")]
    string Name,

    [Required]
    string Description,

    [Required(ErrorMessage = "Poziom zagrożenia jest wymagany")]
    [Range(1, 10, ErrorMessage = "Poziom zagrożenia musi być między 1 a 10")]
    int DangerLevel
);

public record UpdateRegionRequest(
    [Required(ErrorMessage = "Nazwa jest wymagana")]
    string Name,

    [Required]
    string Description,

    [Required(ErrorMessage = "Poziom zagrożenia jest wymagany")]
    [Range(1, 10, ErrorMessage = "Poziom zagrożenia musi być między 1 a 10")]
    int DangerLevel
);

public record CreateEventRequest(
    string   Title,
    string   Description,
    int      BonusPercent,
    DateTime StartsAt,
    DateTime EndsAt
);

public record UpdateEventRequest(
    string   Title,
    string   Description,
    int      BonusPercent,
    DateTime StartsAt,
    DateTime EndsAt
);
