// Regions/RegionsController.cs
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuestBoard.Data;
using QuestBoard.Models;

namespace QuestBoard.Regions;

[ApiController]
[Route("api/regions")]
[Tags("🗺️ Regiony")]
[Authorize]
public class RegionsController : ControllerBase
{
    private readonly IRegionRepository _repo;
    // _db zostawiamy — używany w kilku endpointach bezpośrednio
    private readonly AppDbContext _db;

    public RegionsController(IRegionRepository repo, AppDbContext db)
    {
        _repo = repo;
        _db   = db;
    }

    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<RegionResponse>))]
    public async Task<ActionResult<List<RegionResponse>>> GetAll([FromQuery] int? minDanger)
    {
        var regions = await _repo.GetAllAsync(minDanger);
        if (regions == null) return NotFound();

        // dostosowanie do frontu: dodano Icon w mapowaniu
        var results = regions
            .Select(r => new RegionResponse(r.Id, r.Name, r.Icon, r.Description, r.DangerLevel))
            .ToList();
        return Ok(results);
    }

    [HttpGet("{id}")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(RegionDetailResponse))]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<RegionDetailResponse>> GetById(int id)
    {
        if (id <= 0) return BadRequest("Id musi być liczbą dodatnią");
        var region = await _repo.GetByIdAsync(id);
        if (region is null) return NotFound();

        var events = await _repo.GetEventsFromRegionAsync(id);

        var eventResponses = events
            .OrderBy(e => e.StartsAt)
            .Select(MapEventToResponse)
            .ToList();

        return Ok(new RegionDetailResponse(
            region.Id, region.Name, region.Description, region.DangerLevel, eventResponses));
    }

    [HttpGet("{id}/quests")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetQuests(int id)
    {
        if (id <= 0) return BadRequest("Id musi być liczbą dodatnią");
        var quests = await _db.Quests
            .Include(q => q.Region).AsNoTracking()
            .Where(q => q.RegionId == id)
            .OrderByDescending(q => q.Difficulty)
            .Select(q => new
            {
                q.Id, q.Title, q.Description,
                Difficulty = q.Difficulty.ToString(),
                q.MinLevel, q.RewardGold, q.Status,
                RegionName = q.Region != null ? q.Region.Name : "Brak regionu",
                q.RequiredClass, q.CompletionReport, q.RejectionReason
            })
            .ToListAsync();

        if (!quests.Any()) return NotFound();
        return Ok(quests);
    }

    [HttpGet("{id}/stats")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetStats(int id)
    {
        if (id <= 0) return BadRequest("Id musi być liczbą dodatnią");
        var regionExists = await _db.Regions.AnyAsync(r => r.Id == id);
        if (!regionExists) return NotFound();

        var result = await _db.Quests.AsNoTracking()
            .Where(q => q.RegionId == id)
            .GroupBy(q => q.RegionId)
            .Select(g => new
            {
                QuestCount     = g.Count(),
                AverageReward  = Math.Round(g.Average(q => q.RewardGold), 2),
                MaxReward      = g.Max(q => q.RewardGold),
            })
            .FirstOrDefaultAsync();

        if (result == null) return NotFound();
        return Ok(result);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<RegionResponse>> Create(CreateRegionRequest request)
    {
        var region = new Region
        {
            Name        = request.Name,
            Description = request.Description,
            DangerLevel = request.DangerLevel,
        };
        var created = await _repo.CreateAsync(region);
        // dostosowanie do frontu: dodano Icon (pusty przy tworzeniu)
        return CreatedAtAction(nameof(GetById), new { id = created.Id },
            new RegionResponse(created.Id, created.Name, created.Icon, created.Description, created.DangerLevel));
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(int id, UpdateRegionRequest updated)
    {
        if (id <= 0) return BadRequest("Id musi być liczbą dodatnią");
        var region = new Region
        {
            Name        = updated.Name,
            Description = updated.Description,
            DangerLevel = updated.DangerLevel,
        };
        var ok = await _repo.UpdateAsync(id, region);
        return ok ? NoContent() : NotFound();
    }

    [HttpPut("{id}/danger")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> UpdateDangerLevel(int id, int dangerLevel)
    {
        if (id <= 0) return BadRequest("Id musi być liczbą dodatnią");
        if (dangerLevel < 1 || dangerLevel > 10)
            return BadRequest("Danger level musi być między 1 a 10");

        var region = await _db.Regions.FindAsync(id);
        if (region is null) return NotFound();

        var hasActiveEvents = await _db.RegionEvents.AnyAsync(e =>
            e.RegionId == id &&
            e.StartsAt <= DateTime.UtcNow &&
            e.EndsAt   >= DateTime.UtcNow);

        if (hasActiveEvents) return Conflict("Region ma aktywne wydarzenia");

        region.DangerLevel = dangerLevel;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        if (id <= 0) return BadRequest("Id musi być liczbą dodatnią");
        var region = await _db.Regions.FindAsync(id);
        if (region is null) return NotFound();

        var hasQuests = await _db.Quests.AnyAsync(q => q.RegionId == id);
        if (hasQuests) return Conflict("Nie można usunąć regionu który ma przypisane questy");

        await _repo.DeleteAsync(id);
        return NoContent();
    }

    [HttpPost("{regionId}/events")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CreateEvent(
        int regionId,
        CreateEventRequest request,
        IValidator<CreateEventRequest> validator)
    {
        var result = await validator.ValidateAsync(request);
        if (!result.IsValid)
        {
            var errors = result.Errors
                .GroupBy(e => e.PropertyName)
                .ToDictionary(g => g.Key, g => g.Select(e => e.ErrorMessage).ToArray());
            return ValidationProblem(new ValidationProblemDetails(errors));
        }

        var regionExists = await _db.Regions.AnyAsync(r => r.Id == regionId);
        if (!regionExists) return NotFound();

        await _repo.CreateEventAsync(new RegionEvent
        {
            Title        = request.Title,
            Description  = request.Description,
            BonusPercent = request.BonusPercent,
            StartsAt     = request.StartsAt,
            EndsAt       = request.EndsAt,
            RegionId     = regionId,
        });
        return NoContent();
    }

    [HttpGet("{id}/events")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<EventResponse>))]
    public async Task<ActionResult<List<EventResponse>>> GetAllEventsFromRegion(int id)
    {
        if (id <= 0) return BadRequest("Id musi być liczbą dodatnią");
        var events = await _repo.GetEventsFromRegionAsync(id);
        return Ok(events.OrderBy(e => e.StartsAt).Select(MapEventToResponse).ToList());
    }

    [HttpGet("/api/events")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<EventResponse>))]
    public async Task<ActionResult<List<EventResponse>>> GetAllEvents()
        => Ok((await _repo.GetAllEventsAsync()).Select(MapEventToResponse).ToList());

    [HttpGet("/api/events/active")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<EventResponse>))]
    public async Task<ActionResult<List<EventResponse>>> GetActiveEvents()
        => Ok((await _repo.GetActiveEventsAsync())
            .OrderBy(e => e.StartsAt).Select(MapEventToResponse).ToList());

    [HttpPut("/api/events/{id}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateEvents(int id, UpdateEventRequest updated)
    {
        if (id <= 0) return BadRequest("Id musi być liczbą dodatnią");
        var ok = await _repo.UpdateEventAsync(id, new RegionEvent
        {
            Title        = updated.Title,
            Description  = updated.Description,
            BonusPercent = updated.BonusPercent,
            StartsAt     = updated.StartsAt,
            EndsAt       = updated.EndsAt,
            RegionId     = id,
        });
        return ok ? NoContent() : NotFound();
    }

    [HttpDelete("/api/events/{id}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteEvents(int id)
    {
        if (id <= 0) return BadRequest("Id musi być liczbą dodatnią");
        var ok = await _repo.DeleteEventAsync(id);
        return ok ? NoContent() : NotFound();
    }

    // dostosowanie do frontu: helper do mapowania eventu — dodano RegionId
    private static EventResponse MapEventToResponse(RegionEvent e) => new(
        e.Id, e.Title, e.Description, e.BonusPercent, e.StartsAt, e.EndsAt, e.RegionId);
}
