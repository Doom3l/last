﻿using Microsoft.EntityFrameworkCore;
using QuestBoard.Data;
using QuestBoard.Models;

namespace QuestBoard.Regions;

public class RegionRepository : IRegionRepository
{
    private readonly AppDbContext _db;

    public RegionRepository(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<Region>> GetAllAsync(int? minDanger = null)
    {
        var query = _db.Regions.AsNoTracking();
        if (minDanger.HasValue)
            query = query.Where(r => r.DangerLevel >= minDanger.Value);
        return await query.OrderBy(r => r.Name).ToListAsync();
    }

    public async Task<Region?> GetByIdAsync(int id)
        => await _db.Regions.FindAsync(id);

    public async Task<Region> CreateAsync(Region region)
    {
        _db.Regions.Add(region);
        await _db.SaveChangesAsync();
        return region;
    }

    public async Task<bool> UpdateAsync(int id, Region updated)
    {
        var region = await _db.Regions.FindAsync(id);
        if (region is null) return false;

        region.Name = updated.Name;
        region.Description = updated.Description;
        region.DangerLevel = updated.DangerLevel;

        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var region = await _db.Regions.FindAsync(id);
        if (region is null) return false;

        _db.Regions.Remove(region);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<List<RegionEvent>> GetEventsFromRegionAsync(int regionId)
    {
        var query = await _db.RegionEvents
            .Include(e => e.Region)
            .AsNoTracking()
            .Where(e => e.RegionId == regionId)
            .ToListAsync();
        return query;
    }

    public async Task<List<RegionEvent>> GetActiveEventsAsync()
    {
        var query = await _db.RegionEvents
            .Include(e => e.Region)
            .AsNoTracking()
            .Where(e => e.StartsAt <= DateTime.UtcNow && e.EndsAt >= DateTime.UtcNow)
            .ToListAsync();
        return query;
    }

    public async Task<RegionEvent> CreateEventAsync(RegionEvent e)
    {
        _db.RegionEvents.Add(e);
        await _db.SaveChangesAsync();
        return e;
    }

    public async Task<bool> UpdateEventAsync(int id, RegionEvent updated)
    {
        var events = await _db.RegionEvents.FindAsync(id);
        if (events is null) return false;

        events.Title = updated.Title;
        events.Description = updated.Description;
        events.StartsAt = updated.StartsAt;
        events.EndsAt = updated.EndsAt;
        events.RegionId = updated.RegionId;

        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteEventAsync(int id)
    {
        var existingEvent = await _db.RegionEvents.FindAsync(id);
        if (existingEvent is null) return false;

        _db.RegionEvents.Remove(existingEvent);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<RegionEvent?>
    GetActiveEventForRegionAsync(int regionId)
    => await _db.RegionEvents
        .AsNoTracking()
        .Where(e => e.RegionId == regionId
                 && e.StartsAt <= DateTime.UtcNow
                 && e.EndsAt >= DateTime.UtcNow)
        .FirstOrDefaultAsync();

    public async Task<List<RegionEvent>> GetAllEventsAsync()
    => await _db.RegionEvents
        .Include(e => e.Region)
        .AsNoTracking()
        .ToListAsync();
}