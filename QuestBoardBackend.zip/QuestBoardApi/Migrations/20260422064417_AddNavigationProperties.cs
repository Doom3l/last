﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace QuestBoard.Migrations
{
    /// <inheritdoc />
    public partial class AddNavigationProperties : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_RegionEvents_RegionId",
                table: "RegionEvents",
                column: "RegionId");

            migrationBuilder.CreateIndex(
                name: "IX_Quests_RegionId",
                table: "Quests",
                column: "RegionId");

            migrationBuilder.CreateIndex(
                name: "IX_QuestHeroes_HeroId",
                table: "QuestHeroes",
                column: "HeroId");

            migrationBuilder.AddForeignKey(
                name: "FK_QuestHeroes_Heroes_HeroId",
                table: "QuestHeroes",
                column: "HeroId",
                principalTable: "Heroes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_QuestHeroes_Quests_QuestId",
                table: "QuestHeroes",
                column: "QuestId",
                principalTable: "Quests",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Quests_Regions_RegionId",
                table: "Quests",
                column: "RegionId",
                principalTable: "Regions",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_RegionEvents_Regions_RegionId",
                table: "RegionEvents",
                column: "RegionId",
                principalTable: "Regions",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_QuestHeroes_Heroes_HeroId",
                table: "QuestHeroes");

            migrationBuilder.DropForeignKey(
                name: "FK_QuestHeroes_Quests_QuestId",
                table: "QuestHeroes");

            migrationBuilder.DropForeignKey(
                name: "FK_Quests_Regions_RegionId",
                table: "Quests");

            migrationBuilder.DropForeignKey(
                name: "FK_RegionEvents_Regions_RegionId",
                table: "RegionEvents");

            migrationBuilder.DropIndex(
                name: "IX_RegionEvents_RegionId",
                table: "RegionEvents");

            migrationBuilder.DropIndex(
                name: "IX_Quests_RegionId",
                table: "Quests");

            migrationBuilder.DropIndex(
                name: "IX_QuestHeroes_HeroId",
                table: "QuestHeroes");
        }
    }
}
