﻿namespace QuestBoard.Models;

public class QuestHero
{
    public int QuestId { get; set; }
    public int HeroId { get; set; }
    public bool IsLeader { get; set; }
    public DateTime JoinedAt { get; set; }

    public Quest Quest { get; set; } = null!;
    public Hero Hero { get; set; } = null!;
}