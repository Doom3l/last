﻿namespace QuestBoard.Models;

public class Item
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Icon { get; set; } = "";
    public ItemType Type { get; set; }
    public int Value { get; set; }
    public string Description { get; set; } = "";
}

public enum ItemType { Weapon, Armor, Talisman }