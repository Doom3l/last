﻿namespace QuestBoard.Models;

public class HeroItem
{
    public int HeroId { get; set; }
    public int ItemId { get; set; }
    public DateTime AcquiredAt { get; set; }

    public Hero Hero { get; set; } = null!;
    public Item Item { get; set; } = null!;
}