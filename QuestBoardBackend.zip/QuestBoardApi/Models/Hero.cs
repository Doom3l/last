﻿namespace QuestBoard.Models;

public class Hero
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Icon { get; set; } = "";
    public HeroClass Class { get; set; }
    public int Level { get; set; }
    public int GoldCoins { get; set; }
    public List<QuestHero> QuestHeroes { get; set; } = [];
    public List<HeroItem> HeroItems { get; set; } = [];
}

public enum HeroClass { Warrior, Mage, Ranger, Paladin }