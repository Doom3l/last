﻿namespace QuestBoard.Models;

public class Quest
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string Icon { get; set; } = "";
    public Difficulty Difficulty { get; set; }
    public int MinLevel { get; set; }
    public int RewardGold { get; set; }
    public QuestStatus Status { get; set; }
    public int RegionId { get; set; }
    public HeroClass? RequiredClass { get; set; }
    public string? CompletionReport { get; set; }
    public string? RejectionReason { get; set; }

    // Models/Quest.cs — dopisz właściwość nawigacyjną (RegionId już tam jest)
    public Region Region { get; set; } = null!;

    public List<QuestHero> QuestHeroes { get; set; } = [];
}

public enum Difficulty { Easy, Medium, Hard }
public enum QuestStatus { Open, InProgress, InReview, Completed, Rejected }
