﻿namespace QuestBoard.Models;

public class RegionEvent
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public int BonusPercent { get; set; }
    public DateTime StartsAt { get; set; }
    public DateTime EndsAt { get; set; }
    public int RegionId { get; set; }
    public Region Region { get; set; } = null!;
}
