﻿namespace QuestBoard.Models;

public class User
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string Role { get; set; } = "Hero";  // Hero lub Admin

    public int? HeroId { get; set; }
    public Hero? Hero { get; set; }
}