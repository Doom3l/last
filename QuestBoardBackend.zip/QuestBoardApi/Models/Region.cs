﻿namespace QuestBoard.Models;

public class Region
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Icon { get; set; } = "";
    public string Description { get; set; } = "";
    public int DangerLevel { get; set; }

    // Models/Region.cs — dopisz kolekcję po stronie "jeden"
    public List<Quest> Quests { get; set; } = [];
    public List<RegionEvent> Events { get; set; } = [];
}