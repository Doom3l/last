﻿using Microsoft.EntityFrameworkCore;
using QuestBoard.Models;
using System.Reflection.Emit;

namespace QuestBoard.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options) { }

    public DbSet<Quest> Quests { get; set; }
    public DbSet<Region> Regions { get; set; }
    public DbSet<Hero> Heroes { get; set; }
    public DbSet<Item> Items { get; set; }
    public DbSet<QuestHero> QuestHeroes { get; set; }
    public DbSet<RegionEvent> RegionEvents { get; set; }
    public DbSet<HeroItem> HeroItems { get; set; }
    public DbSet<User> Users { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // QuestHero ma klucz złożony — EF Core nie odgadnie tego z konwencji
        modelBuilder.Entity<QuestHero>()
            .HasKey(qh => new { qh.QuestId, qh.HeroId });

        modelBuilder.Entity<HeroItem>()
            .HasKey(hi => new { hi.HeroId, hi.ItemId });

        modelBuilder.Entity<User>().HasData(new User { 
            Id = 1, 
            Username = "admin", 
            PasswordHash = "$2a$11$ATsZq6sXPgHZwr.mh6uEKO4dX4IGFURqG3nCwljteaIDoue0hr74K", 
            Role = "Admin", 
            HeroId = null 
        });
    }

}