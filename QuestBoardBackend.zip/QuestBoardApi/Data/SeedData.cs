// ════════════════════════════════════════════════════════
//  QuestBoard — dane testowe
//
//  LAB-1 / LAB-2: używaj SeedData.linq w LINQPad
//  LAB-3+:        dodaj ten plik do projektu Visual Studio
//                 i wywołaj context.Seed() w Program.cs
// ════════════════════════════════════════════════════════

using Microsoft.EntityFrameworkCore;
using QuestBoard.Models;

namespace QuestBoard.Data;

public static class SeedData
{
    // ── Metoda główna ─────────────────────────────────────

    public static void Seed(this AppDbContext context)
    {
        if (context.Regions.Any()) return;

        using var transaction = context.Database.BeginTransaction();

        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Regions ON");
        context.Regions.AddRange(GetRegions());
        context.SaveChanges();
        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Regions OFF");

        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT RegionEvents ON");
        context.RegionEvents.AddRange(GetRegionEvents());
        context.SaveChanges();
        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT RegionEvents OFF");

        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Quests ON");
        context.Quests.AddRange(GetQuests());
        context.SaveChanges();
        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Quests OFF");

        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Heroes ON");
        context.Heroes.AddRange(GetHeroes());
        context.SaveChanges();
        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Heroes OFF");

        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Items ON");
        context.Items.AddRange(GetItems());
        context.SaveChanges();
        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Items OFF");

        context.QuestHeroes.AddRange(GetQuestHeroes());
        context.SaveChanges();

        // ── Konta studentów ── dodawane po bohaterach (wymagana kolejność)
        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Users ON");
        context.Users.AddRange(GetUsers());
        context.SaveChanges();
        context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Users OFF");

        transaction.Commit();
    }

    // ── Regiony ──────────────────────────────────────────

    public static List<Region> GetRegions() => new()
    {
        new Region { Id = 1, Name = "Mroczny Las",       Icon = "🌲", Description = "Gęsty las pełen cieni i niebezpiecznych stworzeń.",       DangerLevel = 4 },
        new Region { Id = 2, Name = "Górskie Przełęcze", Icon = "⛰️",  Description = "Strome szlaki i lodowate wiatry.",                         DangerLevel = 7 },
        new Region { Id = 3, Name = "Nawiedzony Zamek",  Icon = "🏰", Description = "Ruiny dawnej twierdzy, gdzie błąkają się duchy.",          DangerLevel = 8 },
        new Region { Id = 4, Name = "Dolina Mgieł",      Icon = "🌫️",  Description = "Spokojne łąki spowite tajemniczą mgłą.",                   DangerLevel = 2 },
        new Region { Id = 5, Name = "Spalone Pustkowia", Icon = "🔥", Description = "Jałowa ziemia po dawnej wojnie magów.",                    DangerLevel = 6 },
        new Region { Id = 6, Name = "Zielony Las",       Icon = "🍃", Description = "Przyjazny las elfów, rzadko nawiedzany przez złe stwory.", DangerLevel = 1 },
    };

    // ── Wydarzenia ────────────────────────────────────────

    public static List<RegionEvent> GetRegionEvents() => new()
    {
        new RegionEvent { Id = 1, RegionId = 2, Title = "Smocza Burza",    Description = "Smok krąży nad przełęczami.",          BonusPercent = 20,
                          StartsAt = new DateTime(2026, 6,  1, 0, 0, 0, DateTimeKind.Utc),
                          EndsAt   = new DateTime(2026, 6, 30, 0, 0, 0, DateTimeKind.Utc) },
        new RegionEvent { Id = 2, RegionId = 1, Title = "Nocna Mgła",      Description = "Gęsta mgła utrudnia wędrówkę.",         BonusPercent =  0,
                          StartsAt = new DateTime(2026, 6,  1, 0, 0, 0, DateTimeKind.Utc),
                          EndsAt   = new DateTime(2026, 6, 30, 0, 0, 0, DateTimeKind.Utc) },
        new RegionEvent { Id = 3, RegionId = 3, Title = "Pełnia Księżyca", Description = "Nieumarli silniejsi tej nocy.",          BonusPercent = 15,
                          StartsAt = new DateTime(2026, 6,  1, 0, 0, 0, DateTimeKind.Utc),
                          EndsAt   = new DateTime(2026, 6, 30, 0, 0, 0, DateTimeKind.Utc) },
    };

    // ── Questy ───────────────────────────────────────────

    public static List<Quest> GetQuests() => new()
    {
        new Quest { Id =  1, Icon = "🗺️",  Title = "Zaginiony kupiec",     Description = "Odnajdź kupca zaginionego w Mrocznym Lesie.",                  Difficulty = Difficulty.Easy,   MinLevel = 2, RewardGold =  80, Status = QuestStatus.Open,       RegionId = 1 },
        new Quest { Id =  2, Icon = "🐺", Title = "Wilki w dolinie",      Description = "Przepędź watahę wilków terroryzujących Dolinę Mgieł.",         Difficulty = Difficulty.Easy,   MinLevel = 1, RewardGold =  50, Status = QuestStatus.Open,       RegionId = 4 },
        new Quest { Id =  3, Icon = "💎", Title = "Skarb w ruinach",      Description = "Eksploruj ruiny Nawiedzonego Zamku i odnajdź zaginiony skarb.",Difficulty = Difficulty.Hard,   MinLevel = 6, RewardGold = 400, Status = QuestStatus.Open,       RegionId = 3 },
        new Quest { Id =  4, Icon = "⚔️",  Title = "Gobliński napad",      Description = "Odpędź goblinów atakujących wioskę na skraju lasu.",           Difficulty = Difficulty.Medium, MinLevel = 3, RewardGold = 150, Status = QuestStatus.InProgress, RegionId = 1 },
        new Quest { Id =  5, Icon = "🔮", Title = "Zaklęty artefakt",     Description = "Odnajdź i zniszcz przeklęty artefakt dawnych magów.",          Difficulty = Difficulty.Hard,   MinLevel = 7, RewardGold = 500, Status = QuestStatus.Open,       RegionId = 5, RequiredClass = HeroClass.Mage },
        new Quest { Id =  6, Icon = "🛡️",  Title = "Straż przełęczy",      Description = "Pilnuj szlaku przez Górskie Przełęcze przez trzy doby.",       Difficulty = Difficulty.Medium, MinLevel = 4, RewardGold = 200, Status = QuestStatus.Open,       RegionId = 2 },
        new Quest { Id =  7, Icon = "🌉", Title = "Troll pod mostem",     Description = "Pokonaj trolla blokującego jedyny most w dolinie.",            Difficulty = Difficulty.Medium, MinLevel = 3, RewardGold = 180, Status = QuestStatus.Completed,  RegionId = 4, CompletionReport = "Pokonaliśmy trolla po długiej walce. Most jest znów wolny." },
        new Quest { Id =  8, Icon = "⛏️",  Title = "Oczyszczenie kopalni", Description = "Oczyść opuszczoną kopalnię w górach z goblinów.",              Difficulty = Difficulty.Hard,   MinLevel = 5, RewardGold = 350, Status = QuestStatus.Open,       RegionId = 2 },
        new Quest { Id =  9, Icon = "📜", Title = "List do elfów",        Description = "Dostarcz pilną wiadomość do elfiej osady w Zielonym Lesie.",   Difficulty = Difficulty.Easy,   MinLevel = 1, RewardGold =  60, Status = QuestStatus.Open,       RegionId = 6 },
        new Quest { Id = 10, Icon = "💀", Title = "Nekromanta w zamku",   Description = "Pokonaj nekromantę który opanował skrzydło ruin.",             Difficulty = Difficulty.Hard,   MinLevel = 8, RewardGold = 600, Status = QuestStatus.Open,       RegionId = 3, RequiredClass = HeroClass.Mage },
        new Quest { Id = 11, Icon = "🌿", Title = "Zioła lecznicze",      Description = "Zbierz rzadkie zioła rosnące głęboko w Mrocznym Lesie.",       Difficulty = Difficulty.Easy,   MinLevel = 2, RewardGold =  70, Status = QuestStatus.InReview,   RegionId = 1, CompletionReport = "Zebraliśmy pełen koszyk ziół. Wszystkie gatunki z listy." },
        new Quest { Id = 12, Icon = "💰", Title = "Bandyci na trakcie",   Description = "Rozgrom bandytów rabujących kupców na Spalonych Pustkowiach.", Difficulty = Difficulty.Medium, MinLevel = 4, RewardGold = 220, Status = QuestStatus.Open,       RegionId = 5 },
        new Quest { Id = 13, Icon = "🏃", Title = "Zagubione dzieci",     Description = "Odnajdź dzieci zaginione podczas wyprawy do lasu.",            Difficulty = Difficulty.Easy,   MinLevel = 1, RewardGold =  90, Status = QuestStatus.Completed,  RegionId = 6, CompletionReport = "Dzieci odnalezione. Były schowane w starej jaskini." },
        new Quest { Id = 14, Icon = "🐉", Title = "Smok w przełęczy",     Description = "Przepędź młodego smoka który zajął jaskinię na szlaku.",       Difficulty = Difficulty.Hard,   MinLevel = 9, RewardGold = 800, Status = QuestStatus.Open,       RegionId = 2 },
        new Quest { Id = 15, Icon = "🧿", Title = "Klątwa wioski",        Description = "Znajdź źródło klątwy trapiącej wioskę przy dolinie.",          Difficulty = Difficulty.Medium, MinLevel = 5, RewardGold = 250, Status = QuestStatus.Open,       RegionId = 4, RequiredClass = HeroClass.Mage },
        new Quest { Id = 16, Icon = "🐎", Title = "Eskortuj karawanę",    Description = "Eskortuj karawanę kupiecką przez Mroczny Las.",                Difficulty = Difficulty.Medium, MinLevel = 3, RewardGold = 170, Status = QuestStatus.Open,       RegionId = 1 },
        new Quest { Id = 17, Icon = "👻", Title = "Duch rycerza",         Description = "Uwolnij ducha rycerza uwięzionego w zamkowej kaplicy.",        Difficulty = Difficulty.Medium, MinLevel = 5, RewardGold = 230, Status = QuestStatus.Rejected,   RegionId = 3, CompletionReport = "Próbowaliśmy odprawić ducha.", RejectionReason = "Raport zbyt ogólny. Opisz szczegółowo zastosowany rytuał." },
        new Quest { Id = 18, Icon = "☠️",  Title = "Trucizna w studni",    Description = "Znajdź kto zatruł jedyną studnię na pustkowiach.",             Difficulty = Difficulty.Hard,   MinLevel = 6, RewardGold = 420, Status = QuestStatus.Open,       RegionId = 5 },
        new Quest { Id = 19, Icon = "⚰️",  Title = "Strażnik grobowca",    Description = "Zniszcz nieumarłego strażnika pilnującego starego grobowca.",  Difficulty = Difficulty.Hard,   MinLevel = 7, RewardGold = 480, Status = QuestStatus.Open,       RegionId = 3 },
        new Quest { Id = 20, Icon = "🔍", Title = "Zaginiony patrol",     Description = "Odnajdź zwiadowców gildii którzy nie wrócili z rekonesansu.",  Difficulty = Difficulty.Medium, MinLevel = 4, RewardGold = 190, Status = QuestStatus.Open,       RegionId = 2 },
    };

    // ── Bohaterowie ──────────────────────────────────────

    public static List<Hero> GetHeroes() => new()
    {
        new Hero { Id =  1, Name = "Thorin",   Icon = "⚔️",  Class = HeroClass.Warrior, Level = 7, GoldCoins = 320 },
        new Hero { Id =  2, Name = "Arindel",  Icon = "🏹", Class = HeroClass.Ranger,  Level = 5, GoldCoins = 180 },
        new Hero { Id =  3, Name = "Malgath",  Icon = "🧙", Class = HeroClass.Mage,    Level = 8, GoldCoins = 540 },
        new Hero { Id =  4, Name = "Sera",     Icon = "🛡️",  Class = HeroClass.Paladin, Level = 4, GoldCoins = 210 },
        new Hero { Id =  5, Name = "Aldric",   Icon = "⚔️",  Class = HeroClass.Warrior, Level = 3, GoldCoins =  90 },
        new Hero { Id =  6, Name = "Ysera",    Icon = "🧙", Class = HeroClass.Mage,    Level = 6, GoldCoins = 430 },
        new Hero { Id =  7, Name = "Bronn",    Icon = "⚔️",  Class = HeroClass.Warrior, Level = 2, GoldCoins =  40 },
        new Hero { Id =  8, Name = "Aelindra", Icon = "🏹", Class = HeroClass.Ranger,  Level = 9, GoldCoins = 750 },
        new Hero { Id =  9, Name = "Gorak",    Icon = "⚔️",  Class = HeroClass.Warrior, Level = 5, GoldCoins = 160 },
        new Hero { Id = 10, Name = "Sylvara",  Icon = "🧙", Class = HeroClass.Mage,    Level = 3, GoldCoins = 120 },
        new Hero { Id = 11, Name = "Durgin",   Icon = "🛡️",  Class = HeroClass.Paladin, Level = 6, GoldCoins = 290 },
        new Hero { Id = 12, Name = "Arannis",  Icon = "🏹", Class = HeroClass.Ranger,  Level = 4, GoldCoins = 140 },
        new Hero { Id = 13, Name = "Krag",     Icon = "⚔️",  Class = HeroClass.Warrior, Level = 1, GoldCoins =  20 },
        new Hero { Id = 14, Name = "Miriel",   Icon = "🧙", Class = HeroClass.Mage,    Level = 7, GoldCoins = 480 },
        new Hero { Id = 15, Name = "Aldara",   Icon = "🛡️",  Class = HeroClass.Paladin, Level = 2, GoldCoins =  55 },
        new Hero { Id = 16, Name = "Fenris",   Icon = "⚔️",  Class = HeroClass.Warrior, Level = 6, GoldCoins = 270 },
        new Hero { Id = 17, Name = "Lyria",    Icon = "🏹", Class = HeroClass.Ranger,  Level = 7, GoldCoins = 390 },
        new Hero { Id = 18, Name = "Zorn",     Icon = "⚔️",  Class = HeroClass.Warrior, Level = 4, GoldCoins = 100 },
        new Hero { Id = 19, Name = "Caelia",   Icon = "🧙", Class = HeroClass.Mage,    Level = 5, GoldCoins = 310 },
        new Hero { Id = 20, Name = "Halvard",  Icon = "🛡️",  Class = HeroClass.Paladin, Level = 8, GoldCoins = 620 },
    };

    // ── Itemy ────────────────────────────────────────────

    public static List<Item> GetItems() => new()
    {
        new Item { Id =  1, Name = "Miecz Krótki",       Icon = "⚔️",  Type = ItemType.Weapon,   Value =  80, Description = "Lekki miecz dla początkujących wojowników." },
        new Item { Id =  2, Name = "Długi Miecz",        Icon = "🗡️",  Type = ItemType.Weapon,   Value = 150, Description = "Solidna broń dla doświadczonych." },
        new Item { Id =  3, Name = "Topór Bojowy",       Icon = "🪓", Type = ItemType.Weapon,   Value = 200, Description = "Ciężki topór zadający ogromne obrażenia." },
        new Item { Id =  4, Name = "Łuk Elficki",        Icon = "🏹", Type = ItemType.Weapon,   Value = 180, Description = "Precyzyjny łuk elfich rzemieślników." },
        new Item { Id =  5, Name = "Laska Maga",         Icon = "🔮", Type = ItemType.Weapon,   Value = 160, Description = "Wzmacnia zaklęcia o 15%." },
        new Item { Id =  6, Name = "Różdżka Piorunów",   Icon = "⚡", Type = ItemType.Weapon,   Value = 350, Description = "Rzuca błyskawice — tylko dla magów." },
        new Item { Id =  7, Name = "Sztylet Cienia",     Icon = "🔪", Type = ItemType.Weapon,   Value = 110, Description = "Lekki i szybki, idealny dla zwiadowców." },
        new Item { Id =  8, Name = "Skórzana Zbroja",    Icon = "🥋", Type = ItemType.Armor,    Value =  60, Description = "Lekka ochrona nie ograniczająca ruchów." },
        new Item { Id =  9, Name = "Kolczuga",           Icon = "🛡️",  Type = ItemType.Armor,    Value = 140, Description = "Solidna ochrona dla awanturników." },
        new Item { Id = 10, Name = "Płytowa Zbroja",     Icon = "⚜️",  Type = ItemType.Armor,    Value = 300, Description = "Maksymalna ochrona — tylko dla wojowników." },
        new Item { Id = 11, Name = "Tarcza Herbu",       Icon = "🔰", Type = ItemType.Armor,    Value = 120, Description = "Wytrzymała tarcza z herbem gildii." },
        new Item { Id = 12, Name = "Zbroja Paladyna",    Icon = "✝️",  Type = ItemType.Armor,    Value = 280, Description = "Święta zbroja wzmacniająca boskie moce." },
        new Item { Id = 13, Name = "Peleryna Zwiadowcy", Icon = "🧥", Type = ItemType.Armor,    Value =  95, Description = "Zapewnia częściową niewidzialność w lesie." },
        new Item { Id = 14, Name = "Amulet Zdrowia",     Icon = "💚", Type = ItemType.Talisman, Value =  90, Description = "Powoli regeneruje zdrowie podczas odpoczynku." },
        new Item { Id = 15, Name = "Pierścień Mocy",     Icon = "💍", Type = ItemType.Talisman, Value = 110, Description = "Zwiększa siłę ataku o 10%." },
        new Item { Id = 16, Name = "Kamień Szczęścia",   Icon = "🍀", Type = ItemType.Talisman, Value =  75, Description = "Podobno przynosi szczęście w trudnych chwilach." },
        new Item { Id = 17, Name = "Talizman Odwagi",    Icon = "🔶", Type = ItemType.Talisman, Value = 130, Description = "Chroni przed efektami strachu i paniki." },
        new Item { Id = 18, Name = "Kryształ Magii",     Icon = "💎", Type = ItemType.Talisman, Value = 220, Description = "Znacznie zwiększa pulę many maga." },
        new Item { Id = 19, Name = "Amulet Ochrony",     Icon = "🔵", Type = ItemType.Talisman, Value = 170, Description = "Pochłania część obrażeń od magii." },
        new Item { Id = 20, Name = "Pierścień Skupienia",Icon = "🟣", Type = ItemType.Talisman, Value = 140, Description = "Zwiększa celność o 12%." },
    };

    // ── QuestHeroes (relacja M:N) ────────────────────────

    public static List<QuestHero> GetQuestHeroes() => new()
    {
        new QuestHero { QuestId =  4, HeroId =  1, IsLeader = true,  JoinedAt = new DateTime(2025, 3,  1,  9,  0, 0) },
        new QuestHero { QuestId =  4, HeroId =  9, IsLeader = false, JoinedAt = new DateTime(2025, 3,  1, 10,  0, 0) },
        new QuestHero { QuestId =  7, HeroId =  2, IsLeader = true,  JoinedAt = new DateTime(2025, 2, 10,  8,  0, 0) },
        new QuestHero { QuestId =  7, HeroId = 12, IsLeader = false, JoinedAt = new DateTime(2025, 2, 10,  8, 30, 0) },
        new QuestHero { QuestId = 11, HeroId =  2, IsLeader = true,  JoinedAt = new DateTime(2025, 3,  5, 14,  0, 0) },
        new QuestHero { QuestId = 11, HeroId = 12, IsLeader = false, JoinedAt = new DateTime(2025, 3,  5, 15,  0, 0) },
        new QuestHero { QuestId = 13, HeroId =  4, IsLeader = true,  JoinedAt = new DateTime(2025, 1, 20, 11,  0, 0) },
        new QuestHero { QuestId = 17, HeroId =  3, IsLeader = true,  JoinedAt = new DateTime(2025, 2, 25,  9,  0, 0) },
        new QuestHero { QuestId = 17, HeroId =  6, IsLeader = false, JoinedAt = new DateTime(2025, 2, 25,  9, 30, 0) },
    };

    // ── Użytkownicy ──────────────────────────────────────
    // Login: nazwisko małymi literami (bez polskich znaków)
    // Hasło: login + "123"
    //
    // Student              Login           Bohater
    // ────────────────────────────────────────────────────
    // Bożek Dawid          bozek           Gorak
    // Bury Roma            bury            Krag
    // Doniec Mariusz       doniec          Aelindra
    // Dzierżawski Tymoteusz dzierzawski    Bronn
    // Grochowski Michał    grochowski      Miriel
    // Iwaniec Mieszko      iwaniec         Arannis
    // Korniak Aleksandra   korniak         Ysera
    // Kostevych Marta      kostevych       Malgath
    // Kotecka Eliza        kotecka         Sylvara
    // Król Kamila          krol            Sera
    // Matoga Karol         matoga          Aldric
    // Meres Tomasz         meres           Thorin
    // Solarz Jakub         solarz          Arindel
    // Stachowicz Jacek     stachowicz      Durgin

    public static List<User> GetUsers() => new()
    {
        new User { Id =  2, Username = "bozek",       PasswordHash = "$2a$11$ktoQ13soCl4orgDdafvm0.v51z60kEI8Tr0QsKezcjuroAvVH8UZO", Role = "Hero", HeroId = 9  },
        new User { Id =  3, Username = "bury",        PasswordHash = "$2a$11$hi1LYp6mYdYyesDX0qbomemaLJNA3RvZwZSrrPiQsd8EhXbqU3.7i", Role = "Hero", HeroId = 13 },
        new User { Id =  4, Username = "doniec",      PasswordHash = "$2a$11$jOcYWIpceP.YRnBhHIqL0eua6mYyuy2hy4xJpIVVM6DO5CbmSeylq", Role = "Hero", HeroId = 8  },
        new User { Id =  5, Username = "dzierzawski", PasswordHash = "$2a$11$EzrF4e8GkLFB8dC2rLBeWenGm0ES2dx5EjsUDz9j9OQERosqWaZ7e", Role = "Hero", HeroId = 7  },
        new User { Id =  6, Username = "grochowski",  PasswordHash = "$2a$11$Nxv06AXWrNn.CqGB.vjTfO1RBwoBZO.9S5htCXWxYJbkeOaV0Rk5i", Role = "Hero", HeroId = 14 },
        new User { Id =  7, Username = "iwaniec",     PasswordHash = "$2a$11$c1QuxRjOIh/4EtJrAzsiU.UYCAq8HE5V9Mn6WxM3yrdBBiVDYRITS", Role = "Hero", HeroId = 12 },
        new User { Id =  8, Username = "korniak",     PasswordHash = "$2a$11$fX277nx92e187JtiW6D01eGmDZ8ejTDbqWdCg3unRaNhWNxn23oeW",  Role = "Hero", HeroId = 6  },
        new User { Id =  9, Username = "kostevych",   PasswordHash = "$2a$11$pexzCHl3OsDsZFVNFXg5zeL.eIFo7mdrI4LSFp0iNB9K3O9N8MUoK", Role = "Hero", HeroId = 3  },
        new User { Id = 10, Username = "kotecka",     PasswordHash = "$2a$11$Qy4iaQG2mp0lFPm3vZ7HquzsIEbkZrfTeTSJW6PwJBHPU.oP90eB6", Role = "Hero", HeroId = 10 },
        new User { Id = 11, Username = "krol",        PasswordHash = "$2a$11$K..k1yfjqDdLKExwt.RCGuVcR5a0sW2OB0R9XpJOo4uv2bcIXGw/S",  Role = "Hero", HeroId = 4  },
        new User { Id = 12, Username = "matoga",      PasswordHash = "$2a$11$4ODVnpuxOKXp1Yy6YGDtB.b8fVpD30iJ7yPKVSguFpMu3AAJg16Im",  Role = "Hero", HeroId = 5  },
        new User { Id = 13, Username = "meres",       PasswordHash = "$2a$11$IPFfsvpJnRoWaQG.l00lMO8zymXg3JfT6en1y72VgdCMwuN.cOLLW",  Role = "Hero", HeroId = 1  },
        new User { Id = 14, Username = "solarz",      PasswordHash = "$2a$11$mgmjuqAojOPAgEYfDz.SS.7ChwaPwQUffv0G2AfYUe7kikUrBECxO",  Role = "Hero", HeroId = 2  },
        new User { Id = 15, Username = "stachowicz",  PasswordHash = "$2a$11$ktNfxKUEoE6H/rhHu8qzw..igHPDgRhQBzn29KGq3a.xuZTCBJKza", Role = "Hero", HeroId = 11 },
    };
}
