﻿using QuestBoard.Models;

namespace QuestBoard.Items;

public class ItemService
{
    private const int InventoryLimit = 5;

    private readonly IItemRepository _repo;

    public ItemService(IItemRepository repo)
    {
        _repo = repo;
    }

    public async Task<bool> BuyItemAsync(int heroId, int itemId)
    {
        var hero = await _repo.GetHeroWithItemsAsync(heroId);
        if (hero is null) return false;

        var item = await _repo.GetByIdAsync(itemId);
        if (item is null) return false;

        if (hero.HeroItems.Any(hi => hi.ItemId == itemId)) return false;
        if (hero.HeroItems.Count >= InventoryLimit) return false;
        if (hero.GoldCoins < item.Value) return false;

        hero.GoldCoins -= item.Value;
        await _repo.UpdateHeroAsync(hero);
        await _repo.AddHeroItemAsync(new HeroItem
        {
            HeroId = heroId,
            ItemId = itemId,
            AcquiredAt = DateTime.UtcNow,
        });
        return true;
    }

    public async Task<bool> SellItemAsync(int heroId, int itemId)
    {
        var hero = await _repo.GetHeroWithItemsAsync(heroId);
        if (hero is null) return false;

        var item = await _repo.GetByIdAsync(itemId);
        if (item is null) return false;

        var heroItem = hero.HeroItems.FirstOrDefault(hi => hi.ItemId == itemId);
        if (heroItem is null) return false;

        hero.GoldCoins += item.Value / 2;
        await _repo.UpdateHeroAsync(hero);
        await _repo.RemoveHeroItemAsync(heroItem);
        return true;
    }
}