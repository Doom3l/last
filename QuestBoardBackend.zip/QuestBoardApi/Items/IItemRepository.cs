﻿using QuestBoard.Models;

namespace QuestBoard.Items;

public interface IItemRepository
{
    Task<List<Item>> GetAllAsync(ItemType? type, int? maxPrice);
    Task<Item?> GetByIdAsync(int id);
    Task<Item> CreateAsync(Item item);
    Task<bool> UpdateAsync(int id, Item updated);
    Task<bool> DeleteAsync(int id);
    Task<List<Item>?> GetInventoryAsync(int heroId);
    Task<int?> GetInventoryValueAsync(int heroId);

    Task<Hero?> GetHeroWithItemsAsync(int heroId);
    Task UpdateHeroAsync(Hero hero);
    Task AddHeroItemAsync(HeroItem heroItem);
    Task RemoveHeroItemAsync(HeroItem heroItem);
}