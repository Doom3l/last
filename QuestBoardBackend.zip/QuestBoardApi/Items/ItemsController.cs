using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using QuestBoard.Models;

namespace QuestBoard.Items;

[ApiController]
[Route("api/items")]
[Tags("🏪 Handlarze")]
public class ItemsController : ControllerBase
{
    private readonly IItemRepository _repo;
    private readonly ItemService     _service;

    public ItemsController(IItemRepository repo, ItemService service)
    {
        _repo    = repo;
        _service = service;
    }

    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<ItemResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<ItemResponse>>> GetAll(
        [FromQuery] ItemType? type,
        [FromQuery] int?      maxPrice)
    {
        var items = await _repo.GetAllAsync(type, maxPrice);
        return Ok(items.Select(MapToResponse).ToList());
    }

    [HttpGet("{id:int}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(ItemResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ItemResponse>> GetById(int id)
    {
        var item = await _repo.GetByIdAsync(id);
        return item is null ? NotFound() : Ok(MapToResponse(item));
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(typeof(ItemResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ItemResponse>> Create(CreateItemRequest request)
    {
        var created = await _repo.CreateAsync(new Item
        {
            Name        = request.Name,
            Icon        = request.Icon ?? "",
            Type        = request.Type,
            Value       = request.Value,
            Description = request.Description ?? "",
        });
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, MapToResponse(created));
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(int id, UpdateItemRequest request)
    {
        var ok = await _repo.UpdateAsync(id, new Item
        {
            Name        = request.Name,
            Icon        = request.Icon ?? "",
            Type        = request.Type,
            Value       = request.Value,
            Description = request.Description ?? "",
        });
        return ok ? NoContent() : NotFound();
    }

    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Admin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var ok = await _repo.DeleteAsync(id);
        return ok ? NoContent() : NotFound();
    }

    [HttpGet("inventory/{heroId:int}")]
    [Authorize]
    [ProducesResponseType(typeof(List<ItemResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<List<ItemResponse>>> GetInventory(int heroId)
    {
        var items = await _repo.GetInventoryAsync(heroId);
        return items is null ? NotFound() : Ok(items.Select(MapToResponse).ToList());
    }

    [HttpGet("inventory/{heroId:int}/value")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetInventoryValue(int heroId)
    {
        var total = await _repo.GetInventoryValueAsync(heroId);
        return total is null
            ? NotFound()
            : Ok(new { HeroId = heroId, TotalValue = total.Value });
    }

    [HttpPost("/api/heroes/me/items/{itemId:int}")]
    [Authorize(Roles = "Hero")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> BuyForMe(int itemId)
    {
        if (!TryGetHeroId(out var heroId)) return BadRequest();
        var ok = await _service.BuyItemAsync(heroId, itemId);
        return ok ? NoContent() : BadRequest();
    }

    [HttpDelete("/api/heroes/me/items/{itemId:int}")]
    [Authorize(Roles = "Hero")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> SellForMe(int itemId)
    {
        if (!TryGetHeroId(out var heroId)) return BadRequest();
        var ok = await _service.SellItemAsync(heroId, itemId);
        return ok ? NoContent() : BadRequest();
    }

    [HttpPost("{itemId:int}/buy")]
    [Authorize(Roles = "Hero")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Buy(int itemId, BuyRequest request)
    {
        var ok = await _service.BuyItemAsync(request.HeroId, itemId);
        return ok ? NoContent() : BadRequest();
    }

    [HttpPost("{itemId:int}/sell")]
    [Authorize(Roles = "Hero")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Sell(int itemId, BuyRequest request)
    {
        var ok = await _service.SellItemAsync(request.HeroId, itemId);
        return ok ? NoContent() : BadRequest();
    }

    private bool TryGetHeroId(out int heroId)
    {
        heroId = 0;
        var claim = User.FindFirst("heroId")?.Value;
        return int.TryParse(claim, out heroId) && heroId > 0;
    }

    // dostosowanie do frontu: Type serializowany jako string zamiast int
    // poprzednio: new(item.Id, item.Name, item.Icon, item.Type, item.Value, item.Description)
    private static ItemResponse MapToResponse(Item item)
        => new(item.Id, item.Name, item.Icon, item.Type.ToString(), item.Value, item.Description);
}
