﻿using Microsoft.EntityFrameworkCore;
using QuestBoard.Data;
using QuestBoard.Models;

namespace QuestBoard.Items;

public class ItemRepository : IItemRepository
{
    private readonly AppDbContext _db;

    public ItemRepository(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<Item>> GetAllAsync(ItemType? type, int? maxPrice)
    {
        var query = _db.Items.AsNoTracking();

        if (type.HasValue) query = query.Where(i => i.Type == type.Value);
        if (maxPrice.HasValue) query = query.Where(i => i.Value <= maxPrice.Value);

        return await query.OrderBy(i => i.Name).ToListAsync();
    }

    public async Task<Item?> GetByIdAsync(int id)
        => await _db.Items.FindAsync(id);

    public async Task<Item> CreateAsync(Item item)
    {
        _db.Items.Add(item);
        await _db.SaveChangesAsync();
        return item;
    }

    public async Task<bool> UpdateAsync(int id, Item updated)
    {
        var item = await _db.Items.FindAsync(id);
        if (item is null) return false;

        item.Name = updated.Name;
        item.Icon = updated.Icon;
        item.Type = updated.Type;
        item.Value = updated.Value;
        item.Description = updated.Description;

        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var item = await _db.Items.FindAsync(id);
        if (item is null) return false;

        _db.Items.Remove(item);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<List<Item>?> GetInventoryAsync(int heroId)
    {
        var hero = await _db.Heroes
            .Include(h => h.HeroItems)
                .ThenInclude(hi => hi.Item)
            .AsNoTracking()
            .FirstOrDefaultAsync(h => h.Id == heroId);

        if (hero is null) return null;

        return hero.HeroItems.Select(hi => hi.Item).ToList();
    }

    public async Task<int?> GetInventoryValueAsync(int heroId)
    {
        var heroExists = await _db.Heroes.AnyAsync(h => h.Id == heroId);
        if (!heroExists) return null;

        return await _db.HeroItems
            .Where(hi => hi.HeroId == heroId)
            .SumAsync(hi => hi.Item.Value);
    }

    public async Task<Hero?> GetHeroWithItemsAsync(int heroId)
        => await _db.Heroes
            .Include(h => h.HeroItems)
            .FirstOrDefaultAsync(h => h.Id == heroId);

    public async Task UpdateHeroAsync(Hero hero)
        => await _db.SaveChangesAsync();

    public async Task AddHeroItemAsync(HeroItem heroItem)
    {
        _db.HeroItems.Add(heroItem);
        await _db.SaveChangesAsync();
    }

    public async Task RemoveHeroItemAsync(HeroItem heroItem)
    {
        _db.HeroItems.Remove(heroItem);
        await _db.SaveChangesAsync();
    }
}