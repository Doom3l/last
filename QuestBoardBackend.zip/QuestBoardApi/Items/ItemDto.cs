using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using QuestBoard.Models;

namespace QuestBoard.Items;

public record ItemResponse(
    int    Id,
    string Name,
    string Icon,
    // dostosowanie do frontu: Type jako string (front filtruje po 'Weapon', 'Armor', 'Talisman')
    // poprzednio: ItemType Type — serializowało jako liczba (0, 1, 2)
    [property: JsonPropertyName("type")] string Type,
    [property: JsonPropertyName("value")] int Value,
    [property: JsonPropertyName("desc")]  string Description
);

public record BuyRequest(
    [Required]
    [Range(1, int.MaxValue)]
    int HeroId
);

public record CreateItemRequest(
    [Required] string Name,
    string?    Icon,
    ItemType   Type,
    [Range(0, int.MaxValue)] int Value,
    string?    Description
);

public record UpdateItemRequest(
    [Required] string Name,
    string?    Icon,
    ItemType   Type,
    [Range(0, int.MaxValue)] int Value,
    string?    Description
);
