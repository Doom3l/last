﻿using System.ComponentModel.DataAnnotations;

namespace QuestBoard.Auth;

public record RegisterRequest(
    [Required] string Username,
    [Required][MinLength(6)] string Password,
    [Required] int HeroId
);

public record LoginRequest(
    [Required] string Username,
    [Required] string Password
);
