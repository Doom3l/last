# QuestBoardBackend

Szablon projektu na kurs .NET 10 — system zarządzania questami QuestBoard.

## Struktura

```
QuestBoardBackend/
├── QuestBoardApi/
│   ├── Data/                   ← wspólne — baza danych (tworzone na zajęciach)
│   ├── Models/                 ← wspólne — klasy encji (tworzone na zajęciach)
│   ├── Quests/                 ← ⚔️ Gildia Questów
│   │   ├── QuestsEndpoints.cs
│   │   └── MEMBERS.md
│   ├── Heroes/                 ← 🧙 Gildia Bohaterów
│   │   ├── HeroesEndpoints.cs
│   │   └── MEMBERS.md
│   ├── Regions/                ← 🗺️ Gildia Regionów
│   │   ├── RegionsEndpoints.cs
│   │   └── MEMBERS.md
│   ├── Items/                  ← 🏪 Gildia Handlarzy
│   │   ├── ItemsEndpoints.cs
│   │   └── MEMBERS.md
│   ├── Program.cs
│   ├── appsettings.json
│   └── QuestBoardApi.csproj
└── QuestBoardBackend.sln
```

## Pierwsze kroki

1. Sklonuj repo i otwórz `QuestBoardBackend.sln` w Visual Studio
2. Sprawdź connection string w `appsettings.json`
3. Dopisz swój login GitHub i imię do `MEMBERS.md` w folderze swojej gildii
4. Uruchom aplikację (`dotnet run`) i otwórz `http://localhost:PORT/swagger`

## Konwencje

- Każda gildia pracuje w swoim folderze
- Pliki wspólne (`Models/`, `Data/`, `Program.cs`) — zmiany po uzgodnieniu z prowadzącym
- Commit message: `💻 LAB-X: [gildia] opis zmian`
